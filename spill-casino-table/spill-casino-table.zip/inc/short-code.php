<?php
/**
 * Generate the shortcode
 * Shortcode : [spilltable id='X']
 */

function STZ_spilltable_shortcode($atts)
{
    ob_start();
    wp_enqueue_style('spill-table-data', STZ_DIR_URL . '/inc/css/spill-table.css', array(), '1.0.0');
    $table_meta = get_post_meta($atts['id']);
    $attached = get_post_meta($atts['id'], 'table_attached_stz_entries', true);
    if (is_array($attached)) {
        ?>
        <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
        <div class="spill-table">
            <table cellspacing="0" cellpadding="0">
                <thead>                        
                </thead>
                <tbody id="dropdown-1" class="dropdown dropdown-processed">
                    <?php 
                    $count_entries = 1;
                    foreach ($attached as $attached_post) {
                        $entry_post = get_post($attached_post);

                        if ($entry_post->post_status=='publish') {
                            $entry_meta = get_post_meta($entry_post->ID);
                            //echo '<pre>' ; print_r($entry_post);die();
                            //echo '<pre>' ; print_r($entry_meta);die();

                            $bounses = get_post_meta($entry_post->ID, 'bonus', true);
                                        
                            $primary_button_text = get_post_meta($entry_post->ID, 'primary_button_text', true);
                            if (!$primary_button_text) {
                                $primary_button_text = 'Play Right Now';
                            }
                                        
                            $primary_button_link = get_post_meta($entry_post->ID, 'primary_button_link', true);
                            if (!$primary_button_link) {
                                $primary_button_link = '#';
                            }

                            $primary_button_link_target = get_post_meta($entry_post->ID, 'primary_button_link_target', true);
                            $primary_link_target = '_self';
                            if ($primary_button_link_target[0]=='on') {
                                $primary_link_target = '_blank';
                            }

                            $secondary_button_text = get_post_meta($entry_post->ID, 'secondary_button_text', true);
                            if (!$secondary_button_text) {
                                $secondary_button_text = 'Read Review';
                            }

                            $secondary_button_link = get_post_meta($entry_post->ID, 'secondary_button_link', true);
                            if (!$secondary_button_link) {
                                $secondary_button_link = '#';
                            }

                            $secondary_button_link_target = get_post_meta($entry_post->ID, 'secondary_button_link_target', true);
                            $secondary_link_target = '_self';
                            if ($secondary_button_link_target[0]=='on') {
                                $secondary_link_target = '_blank';
                            } 
                                                        
                            $additional_text = get_post_meta($entry_post->ID, 'additional_text', true);
                            if ($additional_text[0]=='on') {
                                $additional_text='View More';
                            }

                            
                            ?>
                            <tr>
                                <td width="5%"><?php echo $count_entries; ?> <i class="fa fa-star"></i> </td>
                                
                                <td width="10%">
                                    <?php if (get_post_meta($entry_post->ID, 'logo', true)) : ?>
                                        <img class="spill-table-logo" src="<?php echo get_post_meta($entry_post->ID, 'logo', true); ?>">
                                    <?php endif; ?>
                                </td>
                                <td width="25%">
                                    <h5><?php echo $entry_post->post_title; ?></h5>
                                    <!-- <small>Bonus code: XXXXXX</small> -->
                                </td>
                                <td width="5%">
                                    <div class="tooltip"><i class="fa fa-gift"></i>
                                        <div class="tooltiptext">Exclusive Bonus</div>
                                    </div>
                                </td>
                                <td width="10%" align="center">
                                    <h6>
                                        <?php 
                                            if (!empty($bounses)) {
                                                foreach ($bounses as $bonus) {
                                                    if ('no_deposit_bonus' === $bonus['type']) {
                                                        echo ' NO Deposit Bonus-' . $bonus['amount'] ;
                                                    } elseif ('first_deposit_bonus' === $bonus['type']) {
                                                        echo ' First Deposit Bonus-'. $bonus['amount'];
                                                    } elseif ('free_spins_bonus' === $bonus['type']) {
                                                        echo ' Free Spins Bonus-'. $bonus['amount'];
                                                    } elseif ('reload_bonus' === $bonus['type']) {
                                                        echo ' Reload Bonus-'. $bonus['amount'];
                                                    } elseif ('high_roller_bonus' === $bonus['type']) {
                                                        echo ' High Roller Bonus-'. $bonus['amount'];
                                                    } elseif ('vip_bonus' ===$bonus['type']) {
                                                        echo ' VIP Bonus-'. $bonus['amount'];
                                                    } else {
                                                        //echo ' '. $bonus['amount'];
                                                    }
                                                    echo '<br/>';
                                                }
                                            } ?>
                                    </h6>
                                </td>
                                <!-- <td align="center">
                                    <h6>20xB</h6><small>min WR</small>
                                </td> -->
                                <!-- <td width="12%">
                                    <div class="vote_col">
                                        <span>4.5 <small>/ 1349 votes</small></span>
                                        <div class="vote_box">
                                            <span style="width: 90%;background-color: #5bac5d;"></span>
                                        </div>
                                    </div>
                                </td> -->
                                <td width="30%">
                                    <a href="<?php echo $primary_button_link; ?>" class="claim_button primary_btn" target="<?php echo $primary_link_target; ?>"> <?php echo $primary_button_text; ?> </a>
                                    <!-- <a href="<?php echo $secondary_button_link; ?>" class="claim_button" target="<?php echo $secondary_link_target; ?>"><?php echo $secondary_button_text; ?> <i class="fa fa-gift"></i></a> -->
                                    <a href="#" class="more_button dropdown-link"><?php echo $additional_text; ?> <i class="fa fa-plus"></i></a>
                                </td>
                            </tr>
                            <tr class="dropdown-container" style="display: none;">
                                <td colspan="8">
                                    <table cellpadding="0" cellspacing="0">
                                        <tr>
                                            <td width="50%">
                                                <div class="sub_table">
                                                    <div class="sub_table_top">
                                                        <div class="tooltip pull-right">
                                                            <i class="fa fa-exclamation-circle"></i> 
                                                            <span class="tooltiptext">More Information</span>
                                                        </div>
                                                        <?php 
                                                        if (!empty($bounses)) {
                                                            foreach ($bounses as $bonus) {
                                                                if ('no_deposit_bonus' === $bonus['type']) {
                                                                    echo '<h1><em>$</em>'.$bonus['amount'].'</h1>';
                                                                    echo '<h4>NO Deposit Bonus</h4>';
                                                                } elseif ('first_deposit_bonus' === $bonus['type']) {
                                                                    echo '<h1><em>$</em>'.$bonus['amount'].'</h1>';
                                                                    echo '<h4> First Deposit Bonus</h4>';
                                                                } elseif ('free_spins_bonus' === $bonus['type']) {
                                                                    echo '<h1><em>$</em>'.$bonus['amount'].'</h1>';
                                                                    echo '<h4> Free Spins Bonus</h4>';
                                                                } elseif ('reload_bonus' === $bonus['type']) {   
                                                                    echo '<h1><em>$</em>'.$bonus['amount'].'</h1>';
                                                                    echo '<h4> Reload Bonus</h4>';
                                                                } elseif ('high_roller_bonus' === $bonus['type']) {   
                                                                    echo '<h1><em>$</em>'.$bonus['amount'].'</h1>';
                                                                    echo '<h4> High Roller Bonus</h4>';
                                                                } elseif ('vip_bonus' ===$bonus['type']) {   
                                                                    echo '<h1><em>$</em>'.$bonus['amount'].'</h1>';
                                                                    echo '<h4> VIP Bonus</h4>';
                                                                } else {
                                                                    //echo ' '. '<h1><em>$</em>'.$bonus['amount'].'</h1>';;
                                                                }
                                                            }
                                                        } 
                                                        
                                                        ?>
                                                        
                                                    </div>
                                                    <h4>Details</h4>
                                                    <p><?php echo $description = get_post_meta($entry_post->ID, 'description', true); ?></p>
                                                    <?php
                                                        $rating_integer = get_post_meta($entry_post->ID, 'rating_integer', true);
                                                        if($rating_integer){
                                                            echo '<p>Rating : <strong>'.$rating_integer.'</strong></p>';
                                                        }

                                                        $rating_float = get_post_meta($entry_post->ID, 'rating_float', true);
                                                        if($rating_float){
                                                            echo '<p>Rating Float: <strong>'.$rating_float.'</strong></p>';
                                                        }

                                                        $rating_percents = get_post_meta($entry_post->ID, 'rating_percents', true);
                                                        if($rating_percents){
                                                            echo '<p>Rating Percentage: <strong>'.$rating_percents.'</strong></p>';
                                                        }
                                                    ?>
                                                </div>
                                            </td>
                                            <td width="50%">
                                                <div class="sub_table_right">
                                                    <div class="sub_table_right_col">
                                                        <?php 
                                                            $post_stz_payment_methods = get_the_terms( $entry_post->ID, 'stz_payment_methods' );
                                                            if(is_array($post_stz_payment_methods)){
                                                                echo '<p>Payments</p>
                                                                <div class="wagering_size">';
                                                                
                                                                foreach ( $post_stz_payment_methods as $payment_method ) {
                                                                    $logo = get_term_meta($payment_method->term_id, 'STZ_logo', true);
                                                                    echo '<img src="'.$logo.'">';
                                                                }
                                                                echo ' </div>';
                                                            }
                                                        ?>
                                                        <?php 
                                                            $post_stz_softwares = get_the_terms( $entry_post->ID, 'stz_software' );
                                                            if(is_array($post_stz_softwares)){
                                                                echo '<p>Softwares</p>
                                                                <div class="wagering_size">';
                                                                
                                                                foreach ( $post_stz_softwares as $payment_method ) {
                                                                    $logo = get_term_meta($payment_method->term_id, 'STZ_logo', true);
                                                                    echo '<img src="'.$logo.'">';
                                                                }
                                                                echo ' </div>';
                                                            }
                                                        ?>
                                                        <?php 
                                                            $post_stz_devices = get_the_terms( $entry_post->ID, 'stz_devices' );
                                                            if(is_array($post_stz_devices)){
                                                                echo '<p>Softwares</p>
                                                                <div class="wagering_size">';
                                                                
                                                                foreach ( $post_stz_devices as $payment_method ) {
                                                                    $logo = get_term_meta($payment_method->term_id, 'STZ_logo', true);
                                                                    echo '<img src="'.$logo.'">';
                                                                }
                                                                echo ' </div>';
                                                            }
                                                        ?>
                                                        <?php 
                                                            $post_stz_icons = get_the_terms( $entry_post->ID, 'stz_icons' );
                                                            if(is_array($post_stz_icons)){
                                                                echo '<p>Softwares</p>
                                                                <div class="wagering_size">';
                                                                
                                                                foreach ( $post_stz_icons as $payment_method ) {
                                                                    $logo = get_term_meta($payment_method->term_id, 'STZ_logo', true);
                                                                    echo '<img src="'.$logo.'">';
                                                                }
                                                                echo ' </div>';
                                                            }
                                                        ?>
                                                    </div>
                                                    <center>
                                                    <a href="<?php echo $secondary_button_link; ?>" class="claim_button" target="<?php echo $secondary_link_target; ?>"><?php echo $secondary_button_text; ?> <i class="fa fa-gift"></i></a>
                                                        <div class="w100p pull-left clearfix"></div>
                                                        <div class="stars">
                                                            <div id="rating_<?php echo $entry_post->ID ?>" >
                                                                <input class="star star-5" id="star-5" type="radio" name="star" value="5" />
                                                                <label class="star star-5" for="star-5"></label>
                                                                <input class="star star-4" id="star-4" type="radio" name="star" value="4" />
                                                                <label class="star star-4" for="star-4"></label>
                                                                <input class="star star-3" id="star-3" type="radio" name="star" value="3" />
                                                                <label class="star star-3" for="star-3"></label>
                                                                <input class="star star-2" id="star-2" type="radio" name="star" value="2" />
                                                                <label class="star star-2" for="star-2"></label>
                                                                <input class="star star-1" id="star-1" type="radio" name="star" value="1"/>
                                                                <label class="star star-1" for="star-1"></label>
                                                                <button id="button_<?php echo $entry_post->ID ?>" class="more_button">Submit</button>
                                                                <span id="rating_msg_<?php echo $entry_post->ID ?>"></span>
                                                                <script type="text/javascript">
                                                                    jQuery(document).ready(function(){
                                                                        jQuery("#button_<?php echo $entry_post->ID ?>").on( "click", function(){                                                                           
                                                                            var radioValue = jQuery("#rating_<?php echo $entry_post->ID ?> input[name='star']:checked").val();
                                                                            if(radioValue){
                                                                                jQuery("#button_<?php echo $entry_post->ID ?>").hide();
                                                                               jQuery("#rating_msg_<?php echo $entry_post->ID ?>").text('Thanks for your review');
                                                                            }
                                                                        });
                                                                    });
                                                                </script>
                                                            </div>
                                                        </div>
                                                    </center>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>  
                            <?php
                        }
                    } ?>
                </tbody>                
            </table>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function() {
                jQuery('tbody.dropdown').each(function() {
                    var $dropdown = jQuery(this);
                    jQuery("a.dropdown-link", $dropdown).click(function(e) {
                        e.preventDefault();
                        $current = jQuery("tr a.dropdown-link", $dropdown);
                        $div = jQuery("tr.dropdown-container", $dropdown);

                        $div.toggle();
                        if ($div.is(":visible")) {
                            $current.addClass('show_container');
                        } else {
                            $current.removeClass('show_container');
                        }
                        jQuery("a.dropdown-link").not($current).removeClass('show_container');
                        jQuery("tr.dropdown-container").not($div).hide();
                        return false;
                    });
                });			
            });
        </script>
        <?php
    }
    return ob_get_clean();
}
add_shortcode('spilltable', 'STZ_spilltable_shortcode');

<?php
#Silence is golden